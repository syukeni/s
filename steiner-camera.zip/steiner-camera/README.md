# Steiner Colour Camera

ルドルフ・シュタイナーの色彩論に着想を得た、GitHub Pagesで動かせるブラウザ型カメラアプリです。HTML/CSS/JavaScriptのみで動作します。

## できること

- スマホ／PCのカメラ映像をリアルタイムにCanvasへ描画
- シュタイナー風の色彩フィルターを適用
  - 像／影の色：黒・緑・桃色・白
  - 輝きの色：赤・黄・青
  - 桃色の魂
  - 光と闇の境界
- 前後カメラ切替
- 静止画PNG保存
- GitHub Pagesで公開可能

## GitHub Pagesで動かす方法

1. GitHubで新しいリポジトリを作る
2. `index.html`, `style.css`, `app.js`, `README.md` をアップロードする
3. リポジトリの **Settings > Pages** を開く
4. **Build and deployment** の Source を **Deploy from a branch** にする
5. Branch を `main` / `/root` にして保存
6. 表示された `https://ユーザー名.github.io/リポジトリ名/` にiPhoneのSafariでアクセスする
7. 「カメラを開始」を押して、カメラの使用を許可する

## 注意

カメラAPIはHTTPS環境でないと動きません。GitHub PagesはHTTPSなので適しています。ローカルで動かす場合は `localhost` なら動作しますが、単なるHTTP配信では動かない場合があります。

## 色彩変換の考え方

このアプリは、シュタイナーの思想を厳密な科学的色変換としてではなく、芸術的なフィルターとして実装しています。

- 黒：生命を失ったもの／重い影
- 緑：生命の像
- 桃色：魂の像
- 白：精神の像
- 赤：生命の輝き
- 黄：精神の輝き
- 青：内面・魂の静けさ

