const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d", { willReadFrequently: true });

const startBtn = document.getElementById("startBtn");
const flipBtn = document.getElementById("flipBtn");
const shotBtn = document.getElementById("shotBtn");
const modeSelect = document.getElementById("modeSelect");
const strengthSlider = document.getElementById("strength");
const bloomSlider = document.getElementById("bloom");
const strengthValue = document.getElementById("strengthValue");
const bloomValue = document.getElementById("bloomValue");
const permissionHint = document.getElementById("permissionHint");

let stream = null;
let usingFrontCamera = false;
let animationId = null;

const PALETTES = {
  black: [5, 6, 8],
  green: [42, 104, 58],
  peach: [255, 186, 164],
  white: [255, 248, 226],
  yellow: [255, 211, 87],
  red: [216, 60, 52],
  blue: [55, 79, 156],
};

function clamp(value, min = 0, max = 255) {
  return Math.max(min, Math.min(max, value));
}

function mix(a, b, amount) {
  return a + (b - a) * amount;
}

function mixRGB(rgb, target, amount) {
  return [
    mix(rgb[0], target[0], amount),
    mix(rgb[1], target[1], amount),
    mix(rgb[2], target[2], amount),
  ];
}

function luminance(r, g, b) {
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

function smoothstep(edge0, edge1, x) {
  const t = clamp((x - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

function paletteByStops(t, stops) {
  if (t <= stops[0].at) return stops[0].color;
  for (let i = 0; i < stops.length - 1; i++) {
    const a = stops[i];
    const b = stops[i + 1];
    if (t >= a.at && t <= b.at) {
      const local = (t - a.at) / (b.at - a.at);
      return mixRGB(a.color, b.color, smoothstep(0, 1, local));
    }
  }
  return stops[stops.length - 1].color;
}

function imageColours(r, g, b, strength) {
  const l = luminance(r, g, b);
  const target = paletteByStops(l, [
    { at: 0.00, color: PALETTES.black },
    { at: 0.36, color: PALETTES.green },
    { at: 0.68, color: PALETTES.peach },
    { at: 1.00, color: PALETTES.white },
  ]);

  // 元画像の明暗を少し残し、単なるポスタライズではなく「面の色」に寄せる。
  const gray = [l * 255, l * 255, l * 255];
  const base = mixRGB([r, g, b], gray, 0.18);
  return mixRGB(base, target, strength);
}

function radiance(r, g, b, strength) {
  const l = luminance(r, g, b);
  const target = l < 0.5
    ? mixRGB(PALETTES.blue, PALETTES.red, smoothstep(0.12, 0.55, l))
    : mixRGB(PALETTES.red, PALETTES.yellow, smoothstep(0.45, 0.95, l));

  // 青は沈静、赤は生命、黄は外へ放つ光として重ねる。
  const contrast = (l - 0.5) * 22;
  const base = [r + contrast, g + contrast, b + contrast];
  return mixRGB(base, target, strength * 0.82);
}

function peachSoul(r, g, b, strength) {
  const l = luminance(r, g, b);
  const peachAmount = 0.25 + smoothstep(0.22, 0.88, l) * 0.55;
  const target = mixRGB(PALETTES.peach, PALETTES.white, smoothstep(0.58, 1, l));
  const warmed = [r * 1.06 + 8, g * 1.01 + 4, b * 0.96];
  return mixRGB(warmed, target, strength * peachAmount);
}

function goetheLightDark(r, g, b, strength) {
  const l = luminance(r, g, b);
  const shadow = mixRGB(PALETTES.black, PALETTES.blue, smoothstep(0, 0.48, l));
  const light = mixRGB(PALETTES.yellow, PALETTES.white, smoothstep(0.58, 1, l));
  const boundary = mixRGB(PALETTES.red, PALETTES.green, smoothstep(0.38, 0.62, l));

  let target;
  if (l < 0.42) target = shadow;
  else if (l > 0.64) target = light;
  else target = boundary;

  return mixRGB([r, g, b], target, strength * 0.9);
}

function applyFilter(imageData, mode, strength) {
  const data = imageData.data;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    let out;

    if (mode === "raw") out = [r, g, b];
    if (mode === "imageColours") out = imageColours(r, g, b, strength);
    if (mode === "radiance") out = radiance(r, g, b, strength);
    if (mode === "peachSoul") out = peachSoul(r, g, b, strength);
    if (mode === "goetheLightDark") out = goetheLightDark(r, g, b, strength);

    data[i] = clamp(out[0]);
    data[i + 1] = clamp(out[1]);
    data[i + 2] = clamp(out[2]);
  }

  return imageData;
}

function drawBloom(amount) {
  if (amount <= 0) return;

  ctx.save();
  ctx.globalAlpha = amount * 0.42;
  ctx.globalCompositeOperation = "screen";
  ctx.filter = `blur(${Math.round(8 + amount * 32)}px) saturate(1.18)`;
  ctx.drawImage(canvas, 0, 0, canvas.width, canvas.height);
  ctx.restore();

  ctx.save();
  const gradient = ctx.createRadialGradient(
    canvas.width * 0.52,
    canvas.height * 0.42,
    canvas.width * 0.05,
    canvas.width * 0.52,
    canvas.height * 0.42,
    canvas.width * 0.72,
  );
  gradient.addColorStop(0, `rgba(255, 230, 150, ${amount * 0.16})`);
  gradient.addColorStop(0.48, `rgba(255, 178, 165, ${amount * 0.08})`);
  gradient.addColorStop(1, "rgba(0,0,0,0)");
  ctx.globalCompositeOperation = "screen";
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.restore();
}

function drawFrame() {
  if (!video.videoWidth || !video.videoHeight) {
    animationId = requestAnimationFrame(drawFrame);
    return;
  }

  const videoRatio = video.videoWidth / video.videoHeight;
  const canvasRatio = canvas.width / canvas.height;
  let sx = 0;
  let sy = 0;
  let sw = video.videoWidth;
  let sh = video.videoHeight;

  if (videoRatio > canvasRatio) {
    sw = video.videoHeight * canvasRatio;
    sx = (video.videoWidth - sw) / 2;
  } else {
    sh = video.videoWidth / canvasRatio;
    sy = (video.videoHeight - sh) / 2;
  }

  ctx.drawImage(video, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);

  const strength = Number(strengthSlider.value) / 100;
  const bloom = Number(bloomSlider.value) / 100;
  const mode = modeSelect.value;

  if (mode !== "raw" || strength > 0) {
    const frame = ctx.getImageData(0, 0, canvas.width, canvas.height);
    ctx.putImageData(applyFilter(frame, mode, strength), 0, 0);
  }

  drawBloom(bloom);
  animationId = requestAnimationFrame(drawFrame);
}

async function startCamera() {
  stopCamera();

  const constraints = {
    audio: false,
    video: {
      facingMode: usingFrontCamera ? "user" : "environment",
      width: { ideal: 1280 },
      height: { ideal: 720 },
    },
  };

  try {
    stream = await navigator.mediaDevices.getUserMedia(constraints);
    video.srcObject = stream;
    await video.play();
    permissionHint.style.display = "none";
    animationId = requestAnimationFrame(drawFrame);
  } catch (error) {
    permissionHint.style.display = "block";
    permissionHint.innerHTML = `
      <strong>カメラを開始できませんでした。</strong><br>
      ${error.name}: ${error.message}<br>
      HTTPS上で開いているか、ブラウザのカメラ許可を確認してください。
    `;
  }
}

function stopCamera() {
  if (animationId) cancelAnimationFrame(animationId);
  animationId = null;

  if (stream) {
    stream.getTracks().forEach((track) => track.stop());
  }
  stream = null;
}

function saveStill() {
  const link = document.createElement("a");
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  link.download = `steiner-camera-${timestamp}.png`;
  link.href = canvas.toDataURL("image/png");
  link.click();
}

function updateLabels() {
  strengthValue.textContent = `${strengthSlider.value}%`;
  bloomValue.textContent = `${bloomSlider.value}%`;
}

startBtn.addEventListener("click", startCamera);
flipBtn.addEventListener("click", async () => {
  usingFrontCamera = !usingFrontCamera;
  await startCamera();
});
shotBtn.addEventListener("click", saveStill);
strengthSlider.addEventListener("input", updateLabels);
bloomSlider.addEventListener("input", updateLabels);

updateLabels();

window.addEventListener("pagehide", stopCamera);
